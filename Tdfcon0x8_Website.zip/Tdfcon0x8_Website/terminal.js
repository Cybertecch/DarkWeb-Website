window.onload = function () {
  const terminal = document.getElementById("terminal");

  if (sessionStorage.getItem('terminated') === 'true') {
    terminal.innerHTML = "This session has been terminated. Please refresh to start again.";
    return;
  }

  const banner = `
     .___      ___.        __                           
   __| _/____ _\_ |__ ____/  |_  ____  ____   _____     
  / __ |/ __ \| __ \\__  \   __\/ __ \/ __ \/     \    
 / /_/ \  ___/| \_\ \/ __ \|  | \  ___/  ___/|  Y Y  \   
 \____ |\___  >___  (____  /__|  \___  >___  >__|_|  /   
      \/    \/    \/     \/          \/    \/      \/    

           Tdfcon0x8 :: Terminal Web Console
---------------------------------------------------------
 Version      : 1.0.0
 Author       : Jeff
 Environment  : DarkWeb Sim (OnionShare)

Type a command like "services", "projects", or "contact"
---------------------------------------------------------
 Terminal interface loaded successfully.
`;

  const commands = {
    clear: {
      action: () => {
        terminal.innerHTML = banner;
        return "";
      },
    },
    back: {
      action: () => {
        return "Type a command like 'services', 'projects', or 'contact'.";
      },
    },
    blog: {
      action: () => "Opening blog page...",
    },
    contact: {
      action: () => "Contact us via Discord or secure email.",
    },
    services: {
      action: () => `
Our Services:
 - API Pentesting
 - Web API Integration
 - AI Integration for Modern Websites
`,
    },
    projects: {
      action: () => `
Our Projects:
 1. Web File Project Repository (GitHub)
 2. Wazuh SIEM Installation Guide
`,
    },
    exit: {
      action: () => {
        sessionStorage.setItem('terminated', 'true');
        const exitMessage = document.createElement("div");
        exitMessage.textContent = "Session terminated. Please close this tab.";
        terminal.appendChild(exitMessage);
        scrollToBottom();

        // Attempt to close the tab (won't work in all browsers)
        setTimeout(() => {
          window.close();
        }, 500);

        // Disable input field to prevent further commands
        const inputElement = document.getElementById("terminal-input");
        if (inputElement) {
          inputElement.setAttribute("readonly", "true");
        }

        return "";
      }
    }
  };

  terminal.innerHTML = banner;

  function createInput() {
    const input = document.createElement("input");
    input.setAttribute("id", "terminal-input");
    input.setAttribute("autocomplete", "off");
    input.setAttribute("spellcheck", "false");
    input.style.color = "#39ff14"; // neon green
    input.style.backgroundColor = "black";
    input.style.border = "none";
    input.style.outline = "none";
    terminal.appendChild(input);
    input.focus();
    scrollToBottom();
  }

  function scrollToBottom() {
    terminal.scrollTop = terminal.scrollHeight;
  }

  function handleCommand(inputText) {
    const cmd = inputText.trim().toLowerCase();
    const inputLine = document.createElement("div");
    inputLine.textContent = `> ${cmd}`;
    terminal.appendChild(inputLine);

    if (cmd === "") {
      createInput();
      return;
    } else if (commands.hasOwnProperty(cmd)) {
      const output = commands[cmd].action();
      if (output) {
        const outputLine = document.createElement("div");
        outputLine.textContent = output;
        terminal.appendChild(outputLine);
      }
    } else {
      const errorLine = document.createElement("div");
      errorLine.textContent = `Unknown command: ${cmd}`;
      terminal.appendChild(errorLine);

      const suggestLine = document.createElement("div");
      suggestLine.textContent = `Try: "services", "projects", "contact", "clear", "back", or "exit"`;
      terminal.appendChild(suggestLine);
    }

    createInput();
    scrollToBottom();
  }

  document.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      const inputElement = document.getElementById("terminal-input");
      if (inputElement) {
        const inputValue = inputElement.value;
        inputElement.remove();
        handleCommand(inputValue);
      }
    }
  });

  createInput();
};
